import React, { useEffect, useState } from "react";
import { Button, Form, Select, Avatar, Input } from "antd";
import Icons from "../../component/Icons/Icons";

import ModalField from "../../component/Modal/ModalDemo";
import { GroupStyle } from "./GroupStyle";
import InputDemo from "../../component/Input/InputDemo";
import axios from "../../core/chatRedux/axios";
import { useHistory } from "react-router";
import moment from "moment";
import { getData, setData } from "../../core/locaStorage/Local";
const { Option } = Select;

const GroupSidebar = ({ setSelectedGroup, socket }) => {
  const [openGroupModal, setopenGroupModal] = useState(false);
  const [userListData, setuserListData] = useState([]);
  const [groupList, setgroupList] = useState([]);
  const history = useHistory();
  const [form] = Form.useForm();

  const createGroup = () => {
    setopenGroupModal(true);
    axios
      .getAllUsers({
        Authorization: `Bearer ${
          JSON.parse(localStorage.getItem("user")).token
        }`,
      })
      .then((res) => {
        if (res.data.status === true) {
          const data = [...res.data.data];
          data.forEach((e) => {
            e.value = e.id;
            return e;
          });
          console.log(data);
          setuserListData(data);
        } else {
          setuserListData([]);
        }
      })
      .catch(() => {
        setuserListData([]);
      });
  };

  const setActiveGroup = (item, key) => {
    console.log(item, key);
    setData("groupActive", true);
    setData("selectedGroup", item);
    history.push("/chat/group");
    setSelectedGroup(item);
  };

  const onFinish = (values) => {
    let data = {
      groupName: values.groupName,
      adminId: getData("user").id,
      joinedAt: moment(new Date()).format("YYYY-MM-DD HH:mm:ss"),
      users: values.groupUsers,
    };
    console.log("data", data);
    socket.emit("groupRegistration", data);
    // setgroupList((ee) => {
    //   ee.push(values);
    //   return ee;
    // });
  };

  useEffect(() => {
    socket.on("groupRegistrationResponse", (responce) => {
      console.log("responce", responce);
      setopenGroupModal(false);
      form.resetFields();
      setgroupList((prev) => {
        const list = [...prev];
        list.push(responce);
        setData("GroupList", list);
        return list;
      });
    });
  }, [socket]);

  // useEffect(() => {
  //   setgroupList(JSON.parse(localStorage.getItem("GroupList")));
  // }, [socket]);

  useEffect(() => {
    // const gList = JSON.parse(localStorage.getItem("GroupList"));
    // console.log(gList);
    // setgroupList([...gList]);
    // axios
    //   .getUserGroups({
    //     Authorization: `Bearer ${JSON.parse(localStorage.getItem("token"))}`,
    //   })
    //   .then((res) => {
    //     if (res.data.status === true) {
    //       setgroupList(res.data.data);
    //     } else {
    //       setgroupList([]);
    //     }
    //   })
    //   .catch(() => {
    //     setgroupList([]);
    //   });
  }, []);

  return (
    <GroupStyle>
      <div className="search">
        <span>Group's</span>
        <div className="header--buttons">
          <Icons type="create" onClick={createGroup} />
        </div>
      </div>
      <div className="chatList">
        {console.log(groupList, "sds")}
        {groupList === null ? (
          <div className="nodata">NO GROUP FOUND</div>
        ) : (
          groupList.map((item, key) => (
            <div
              className="chatListItem"
              key={key}
              onClick={() => setActiveGroup(item, key)}
            >
              <Avatar
                style={{ cursor: "pointer", marginLeft: "5px" }}
                size={{
                  xs: 30,
                  sm: 30,
                  md: 30,
                  lg: 30,
                  xl: 30,
                }}
              >
                {!item.groupName ? null : `${item.groupName.charAt(0)}`}
              </Avatar>
              <div className="chatListItem--lines">
                <div
                  className="chatListItem--line"
                  style={{ justifyContent: "unset" }}
                >
                  <div
                    style={{
                      width: "10px",
                      height: "10px",
                      borderRadius: "100%",
                      marginRight: "5px",
                      background: "#10af10",
                    }}
                  />
                  <div className="chatListItem--name"> {item.groupName} </div>
                  {item.newM ? (
                    <div className="chatlistItem--date">
                      <Icons type="newMessage" />
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      <ModalField
        visible={openGroupModal}
        title="Create Group"
        className="uploadmodal"
        onCancel={() => {
          setopenGroupModal(false);
        }}
        footer={
          <Button form="GroupForm" key="submit" htmlType="submit">
            Create
          </Button>
        }
      >
        <div className="CreateGroupForm">
          <Form
            form={form}
            onFinish={onFinish}
            id="GroupForm"
            className=" ant-form-vertical"
            name="basic"
            initialValues={{
              remember: true,
            }}
          >
            <InputDemo
              name="groupName"
              label="Group Name"
              hasFeedback={false}
              rules={[
                {
                  required: true,
                  message: "'GroupName' is required",
                },
              ]}
              Input={
                <Input
                  autoComplete="off"
                  placeholder="Input group name"
                  // onChange={(e) => setusername(e.target.value)}
                />
              }
            />
            <Form.Item
              label="Group Users"
              name="groupUsers"
              rules={[
                {
                  required: true,
                  message: "Select Users",
                },
              ]}
            >
              <Select mode="multiple" placeholder="Please select">
                {userListData &&
                  userListData.map((e) => (
                    <Option key={e.id} value={e.id}>
                      {e.name}
                    </Option>
                  ))}
              </Select>
            </Form.Item>
          </Form>
        </div>
      </ModalField>
    </GroupStyle>
  );
};

export default GroupSidebar;
