export const REGISTER_USER = 'Register_User';
export const LOGIN_USER = "Auth_User";
