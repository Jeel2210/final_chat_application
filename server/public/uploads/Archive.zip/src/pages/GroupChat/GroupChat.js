/* eslint-disable no-unused-vars */
import { Avatar, Button, message, Upload } from "antd";
import React, { useState, useEffect } from "react";
import { RiSendPlaneLine } from "react-icons/ri";
import Icons from "../../component/Icons/Icons";
import ModalField from "../../component/Modal/ModalDemo";
import { getData } from "../../core/locaStorage/Local";

const GroupChat = ({ socket, selectedGroup }) => {
  // const {} = props;
  const [text, setText] = useState("");
  const [recieverD, setRecieverD] = useState({});
  const [messages, setMessages] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [currentUser, setCurrentUser] = useState({});
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState(0);
  const [images, setImages] = useState([]);
  const [groupDeail, setGroupDetail] = useState([]);

  const [fileStatus, setFileStatus] = useState([]);
  const [files, setFiles] = useState([]);
  const [fileLoading, setFileLoading] = useState(false);

  // select Group

  useEffect(() => {
    const groupData = getData("selectedGroup");
    if (groupData && Object.keys(groupData).length !== 0) {
      setGroupDetail(groupData);
    } else {
      setGroupDetail({});
    }
  }, [selectedGroup]);

  const sendData = () => {
    if (text !== "") {
      //final data
      let data = {
        sender: getData("user"),
        type: "chat",
        message: text,
        groupId: groupDeail.groupId,
      };
      data.header = {};
      data.header.auth_token = getData("user").token;
      socket.emit("groupMessages", data);
      setText("");
    }
  };
  useEffect(() => {
    socket.on("groupMessagesResponse", (res) => {
      setMessages((prev) => {
        prev.push(res);
        return prev;
      });
    });
    console.log("groupMessagesResponse", messages);
  }, [socket]);
  return (
    <>
      <div className="chat">
        <div className="user-name">
          <h2>
            <Avatar
              style={{ cursor: "pointer" }}
              size={{
                xs: 30,
                sm: 30,
                md: 30,
                lg: 30,
                xl: 30,
              }}
            >
              {groupDeail.groupName
                ? `${groupDeail.groupName.charAt(0)}`
                : null}
            </Avatar>
            {groupDeail.groupName && Object.keys(groupDeail).length !== 0
              ? groupDeail.groupName
              : "_ _ _"}
          </h2>
        </div>
        ``
        <div className="chat-message">
          {messages.map((i, index) => (
            <div
              className={
                i.sender.id === currentUser.id
                  ? "message mess-right"
                  : "message"
              }
              key={index}
            >
              {console.log(
                "sender",
                i.sender.id,
                "currentUser",
                currentUser.id
              )}
              {i.type === "image" ? (
                <>
                  <span>{i.sender.name}</span>

                  <p
                    className={
                      i.sender.id !== currentUser.id ? "img hoverable" : "img"
                    }
                  >
                    <img
                      src={`${i.text}`}
                      // onClick={() => openImageViewer(0, i.text)}
                      alt="img"
                    />
                  </p>
                  {i.sender.id !== currentUser.id ? (
                    <>
                      <Icons
                        type="Download"
                        // onClick={() => handleDownload(i.text, i.filename)}
                      />
                      <span>{i.date}</span>
                    </>
                  ) : (
                    <span style={{ marginTop: "3px", padding: "unset" }}>
                      <span>{i.date}</span>
                      <Icons
                        type="Download"
                        // onClick={() => handleDownload(i.text, i.filename)}
                      />
                    </span>
                  )}
                </>
              ) : i.type === "file" ? (
                <>
                  <span>{i.sender.name}</span>
                  <p
                    className={
                      i.sender.id !== currentUser.id ? "img hoverable" : "img"
                    }
                  >
                    <span
                      style={{
                        display: "flex",
                        wordBreak: "break-all",
                      }}
                      className={
                        i.sender.id === currentUser.id
                          ? "fileType-right"
                          : "fileType"
                      }
                    >
                      <svg
                        fill="#000000"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 80 80"
                        width="18px"
                        height="18px"
                      >
                        <path d="M 15 9 L 15 71 L 65 71 L 65 23.585938 L 50.414063 9 Z M 17 11 L 49 11 L 49 25 L 63 25 L 63 69 L 17 69 Z M 51 12.414063 L 61.585938 23 L 51 23 Z M 22 13 C 21.449219 13 21 13.449219 21 14 C 21 14.550781 21.449219 15 22 15 C 22.550781 15 23 14.550781 23 14 C 23 13.449219 22.550781 13 22 13 Z M 22 17 C 21.449219 17 21 17.449219 21 18 C 21 18.550781 21.449219 19 22 19 C 22.550781 19 23 18.550781 23 18 C 23 17.449219 22.550781 17 22 17 Z M 22 21 C 21.449219 21 21 21.449219 21 22 C 21 22.550781 21.449219 23 22 23 C 22.550781 23 23 22.550781 23 22 C 23 21.449219 22.550781 21 22 21 Z M 22 25 C 21.449219 25 21 25.449219 21 26 C 21 26.550781 21.449219 27 22 27 C 22.550781 27 23 26.550781 23 26 C 23 25.449219 22.550781 25 22 25 Z M 22 29 C 21.449219 29 21 29.449219 21 30 C 21 30.550781 21.449219 31 22 31 C 22.550781 31 23 30.550781 23 30 C 23 29.449219 22.550781 29 22 29 Z M 22 33 C 21.449219 33 21 33.449219 21 34 C 21 34.550781 21.449219 35 22 35 C 22.550781 35 23 34.550781 23 34 C 23 33.449219 22.550781 33 22 33 Z M 22 37 C 21.449219 37 21 37.449219 21 38 C 21 38.550781 21.449219 39 22 39 C 22.550781 39 23 38.550781 23 38 C 23 37.449219 22.550781 37 22 37 Z M 22 41 C 21.449219 41 21 41.449219 21 42 C 21 42.550781 21.449219 43 22 43 C 22.550781 43 23 42.550781 23 42 C 23 41.449219 22.550781 41 22 41 Z M 22 45 C 21.449219 45 21 45.449219 21 46 C 21 46.550781 21.449219 47 22 47 C 22.550781 47 23 46.550781 23 46 C 23 45.449219 22.550781 45 22 45 Z M 22 49 C 21.449219 49 21 49.449219 21 50 C 21 50.550781 21.449219 51 22 51 C 22.550781 51 23 50.550781 23 50 C 23 49.449219 22.550781 49 22 49 Z M 22 53 C 21.449219 53 21 53.449219 21 54 C 21 54.550781 21.449219 55 22 55 C 22.550781 55 23 54.550781 23 54 C 23 53.449219 22.550781 53 22 53 Z M 22 57 C 21.449219 57 21 57.449219 21 58 C 21 58.550781 21.449219 59 22 59 C 22.550781 59 23 58.550781 23 58 C 23 57.449219 22.550781 57 22 57 Z M 22 61 C 21.449219 61 21 61.449219 21 62 C 21 62.550781 21.449219 63 22 63 C 22.550781 63 23 62.550781 23 62 C 23 61.449219 22.550781 61 22 61 Z M 22 65 C 21.449219 65 21 65.449219 21 66 C 21 66.550781 21.449219 67 22 67 C 22.550781 67 23 66.550781 23 66 C 23 65.449219 22.550781 65 22 65 Z" />
                      </svg>
                      {i.filename}{" "}
                    </span>
                  </p>
                  {i.sender.id !== currentUser.id ? (
                    <>
                      <Icons
                        type="Download"
                        // onClick={() => handleDownload(i.text, i.filename)}
                      />
                      <span>{i.date}</span>
                    </>
                  ) : (
                    <span style={{ marginTop: "3px", padding: "unset" }}>
                      <span>{i.date}</span>
                      <Icons
                        type="Download"
                        // onClick={() => handleDownload(i.text, i.filename)}
                      />
                    </span>
                  )}
                </>
              ) : (
                <>
                  <span>{i.sender.id}</span>
                  <p>{i.message}</p>
                  <span>{i.date}</span>
                </>
              )}
            </div>
          ))}
          {/* <div ref={messagesEndRef} /> */}
        </div>
        <div className="send">
          <input
            placeholder="Enter Your Message"
            value={text}
            disabled={submitted}
            onChange={(e) => setText(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                sendData();
              }
            }}
          ></input>
          <div
            className="btn-box1"
            onClick={
              !submitted
                ? () => setOpenModal(true)
                : () => message.error("Select User to Send File's")
            }
          >
            <Icons className="svgIcon" type="attachemt" />
          </div>
          <div
            className="btn-box"
            onClick={
              !submitted
                ? () => sendData()
                : () =>
                    message.error({
                      content: "Select User to Send Message",
                    })
            }
          >
            <RiSendPlaneLine className="btn-icon" />
          </div>
        </div>
        {/* upload file modal */}
        <ModalField
          visible={openModal}
          title="Attachment"
          className="uploadmodal"
          onCancel={() => {
            setOpenModal(false);
            setFiles([]);
            setFileLoading(false);
          }}
          footer={false}
        >
          <Upload
            name="avatar"
            accept="crt"
            showUploadList={false}
            onChange={(e) => {
              // addFile(e);
            }}
            className="uploadBox"
          >
            <p className="ant-upload-drag-icon">{/* <InboxOutlined /> */}</p>
            <p className="ant-upload-text">Click to this area to upload file</p>
          </Upload>
          <div
            style={{
              maxHeight: "100px",
              overflow: "auto",
              marginTop: "15px",
            }}
            className="overflowDiv"
          >
            {files.length !== 0 &&
              files.map((file, index) => (
                <div
                  className="controlLabel"
                  key={index}
                  style={{ marginTop: "15px" }}
                >
                  {file.name}
                  {`(${file.size / 1000} KB)`}
                  <Icons
                    type="close"
                    icontype="globle"
                    id={`iFiles_close${index}`}
                    className="removeFiles"
                    margin="10px"
                    // onClick={() => removeFile(index)}
                  />
                </div>
              ))}
          </div>
          <div className="footerContent">
            {files.length > 0 ? (
              <Button
                id="warroom_upload"
                disabled={fileStatus.includes(false) || false}
                loading={fileLoading}
                // onClick={addWarroomFile}
              >
                Upload
              </Button>
            ) : null}
          </div>
        </ModalField>
        {/* preview image */}
        {/* {isViewerOpen && (
          <ImageViewer
            src={images}
            currentIndex={currentImage}
            onClose={closeImageViewer}
          />
        )} */}
      </div>
    </>
  );
};

export default GroupChat;
