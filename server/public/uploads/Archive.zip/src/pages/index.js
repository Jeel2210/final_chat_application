import React, { useEffect, useState } from "react";
import { Redirect, Route, Switch } from "react-router";
import axios from "../core/chatRedux/axios";
import { getData, setData } from "../core/locaStorage/Local";
import Chat from "./chat/chat";
import GroupChat from "./GroupChat/GroupChat";
import Sidebar from "./sidebar/Sidebar";
import { PageStyle } from "./style";

const PageRoute = (props) => {
  const { rederpage, socket } = props;
  const [selectedUser, setSelectedUser] = useState({});
  const [selectedGroup, setSelectedGroup] = useState({});
  const [userExist, setUserExist] = useState(false);

  useEffect(() => {
    axios
      .getAllUsers({
        Authorization: `Bearer ${
         getData("user").token
        }`,
      })
      .then((res) => {
        if (res.data.status === true) {
          const userData =getData("user");
          const list = [...res.data.data];
          const index = list.findIndex((e) => e.id === userData.id);
          if (index !== -1) {
            list.splice(index, 1);
          }
          setData("localUserList",list);
        } else {
          setData("localUserList",[]);
        }
      })
      .catch(() => {
        // localStorage.setItem("localUserList", JSON.stringify([]));
      });
  }, []);

  const ActiveGroup = getData("groupActive");
  const Authorize = getData("status");

  return (
    <PageStyle>
      <div className="app_window">
        <Sidebar
          setSelectedUser={setSelectedUser}
          socket={socket}
          setSelectedGroup={setSelectedGroup}
          setUserExist={setUserExist}
        />
        <Route
          render={() =>
            ActiveGroup ? (
              <Redirect to="/chat/group" exact />
            ) : (
              <Redirect to="/chat" />
            )
          }
        ></Route>
         <Route
          render={() =>
            Authorize ? (
              <Redirect to="/chat" exact />
            ) : (
              <Redirect to="/" />
            )
          }
        ></Route>
        <Switch>
          {ActiveGroup ? (
            <Route path="/chat/group">
              <GroupChat socket={socket} selectedGroup={selectedGroup} />
            </Route>
          ) : (
            <Route path="/chat" exact>
              <Chat
                username={props.match.params.username}
                socket={socket}
                selectedUser={selectedUser}
                rederpage={rederpage}
                userExist={userExist}
              />
            </Route>
          )}
        </Switch>
      </div>
    </PageStyle>
  );
};

export default PageRoute;
