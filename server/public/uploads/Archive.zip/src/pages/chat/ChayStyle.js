import styled from "styled-components";
export const ChatStyle = styled.div`
  .chat-message {
    div::-webkit-scrollbar {
      width: 5px;
      height: 5px;
    }

    div::-webkit-scrollbar-thumb {
      background: #1890ff !important;
      border-radius: 10px !important;
    }

    div::-webkit-scrollbar-track {
      background: transparent !important;
      border-radius: 10px !important;
    }
    button{
      display: none !important;
    }
  }
`;
