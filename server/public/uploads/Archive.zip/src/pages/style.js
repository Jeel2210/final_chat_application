import styled from "styled-components";
export const PageStyle = styled.div`
.app_window{
    display: flex;
    background-color: cadetblue;
  }
`;
