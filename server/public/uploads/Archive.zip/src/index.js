import App from "./App";
// import rootReducers from "./store/reducer/index";
import ReactDOM from "react-dom";
// import { createStore } from "redux";
import React from "react";
// import { Provider } from "react-redux";
// import store from "./core/redux/Store";

ReactDOM.render(<App />, document.getElementById("root"));
