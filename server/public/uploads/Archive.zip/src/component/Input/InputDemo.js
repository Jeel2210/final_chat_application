/* eslint-disable react/prop-types */
import React from "react";
import { Form } from "antd";
import { InputStyle } from "./InputStyle";
const InputDemo = (props) => {
  return (
    <>
      <InputStyle>
        <Form.Item
          name={props.name}
          label={props.label}
          dependencies={props.dependencies}
          hasFeedback={props.hasFeedback}
          rules={props.rules}
        >
          {props.Input}
        </Form.Item>
        {props.submitted ? <span>Enter Valid Email</span> : null}{" "}
      </InputStyle>
    </>
  );
};
export default InputDemo;
