module.exports = {
	secretOrKey: "secret"
  };