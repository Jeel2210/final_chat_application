export enum Votes {
  UP = 'upvotes',
  DOWN = 'downvotes',
}
