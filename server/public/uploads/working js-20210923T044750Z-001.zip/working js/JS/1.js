console.log("Javascript  ");

// program to display a text using setTimeout method
// function greet() {
//   console.log("Hello world");
// }

// let intervalId = setTimeout(greet, 3000);
// console.log("Id: " + intervalId);

// program to display time every 3 seconds
// function showTime() {
//   // return new date and time
//   let dateTime = new Date();

//   // returns the current local time
//   let time = dateTime.toLocaleTimeString();

//   console.log("Time ::: ", time);

//   // display the time after 3 seconds
//   setTimeout(showTime, 1000);
// }

// // calling the function
// showTime();

// program to display a name
// function greet(name, lastName) {
//   console.log("Hello" + " " + name + " " + lastName);
// }

// passing argument to setTimeout
// console.log("Hi", setTimeout(greet, 3000, "John", "Doe"));

// // a promise
// let promise = new Promise(function (resolve, reject) {
//   setTimeout(function () {
//     resolve("Promise resolved");
//   }, 4000);
// });

// // async function
// async function asyncFunc() {
//   // wait until the promise resolves
//   let result = await promise;

//   console.log(result);
//   setTimeout(() => {
//     console.log("hello");
//   }, 2500);
// }

// // calling the async function
// asyncFunc();

// // a promise
// let promise = new Promise(function (resolve, reject) {
//   setTimeout(function () {
//     resolve("Promise resolved");
//   }, 4000);
// });

// // async function
// async function asyncFunc() {
//   try {
//     // wait until the promise resolves
//     let result = await promise;

//     console.log(result);
//   } catch (error) {
//     console.log(error);
//   }
// }

// // calling the async function
// asyncFunc(); // Promise resolved

// const text =
//   '{"firstName" : "John","lastName" : "Doe", "age" : " function() {return firstName + " " + lastName;}", "city" : "New York" }';
// const obj = JSON.parse(text);
// obj.age = eval("(" + obj.age + ")");
// console.log(obj.name + ", " + obj.age());

const text =
  '{"fName":"John","lName":"Vasu", "age":"function() {let x = 5; let y = 20; console.log(x+y); return this.fName + this.lName;}", "city":"New York"}';
const obj = JSON.parse(text);
obj.age = eval("(" + obj.age + ")");
console.log(obj.lName + ", " + obj.age());
