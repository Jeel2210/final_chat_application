console.log('Vanila JS');

var taskData = [];
var i = null;
// const updateButton = document.getElementById('updateSong');

function onAdd() {
  var Name = document.getElementById('name').value;
  var Maths = document.getElementById('maths').value;
  var Science = document.getElementById('science').value;
  var English = document.getElementById('english').value;

  // prettier-ignore
  const obj = { "Name": Name, "Maths": Maths, "Science":Science, "English":English };

  taskData.push(obj);

  if (i == null) {
    i = 0;
  }

  for (i = i; i < taskData.length; i++) {
    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
    row.insertCell(0).innerHTML = taskData[i].Name;
    row.insertCell(1).innerHTML = taskData[i].Maths;
    row.insertCell(2).innerHTML = taskData[i].Science;
    row.insertCell(3).innerHTML = taskData[i].English;
    row.insertCell(4).innerHTML = `${
      // Maths && Science && English > 65 ? 'Distinction' : 'fail';
      Maths > 65 && Science > 65 && English > 65
        ? 'Distinction'
        : Maths <= 65 &&
          Maths >= 35 &&
          Science <= 65 &&
          Science >= 35 &&
          English <= 65 &&
          English >= 35
        ? 'pass'
        : 'fail'
    }`;
    row.insertCell(5).innerHTML = `
    <button class="updateButton--${i}" onClick="onUpdate(taskData)">Update</button>
    <button onClick="onDelete(this)">Delete</button>
    `;
  }
}
const sortName = () => {
  function compare(a, b) {
    if (a.Name < b.Name) {
      return -1;
    }
    if (a.Name > b.Name) {
      return 1;
    }
    return 0;
  }
  taskData.sort(compare);
};

function onUpdate(taskData) {
  let btnUpdate = document.getElementById('btnUpdate');
  btnUpdate.value = 'update';

  // console.log('taskData:::', taskData[0]);
  // console.log('taskData000:::', taskData[0][1]);
  document.getElementById('name').value = taskData[0].Name;
  document.getElementById('maths').value = taskData[0].Maths;
  document.getElementById('science').value = taskData[0].Science;
  document.getElementById('english').value = taskData[0].English;
}

function onClear() {
  document.getElementById('name').value = '';
  document.getElementById('maths').value = '';
  document.getElementById('science').value = '';
  document.getElementById('english').value = '';
}

function onDelete(r) {
  var i = r.parentNode.parentNode.rowIndex;
  console.log('Array Index :::', i);

  if (i > 0) {
    document.getElementById('table').deleteRow(i);
  }
}
