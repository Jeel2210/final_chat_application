/* eslint-disable import/no-anonymous-default-export */
import axios from "axios";

// Create instance called instance
const instance = axios.create({
  baseURL: `http://6cb7-122-170-1-34.ngrok.io/`,
  headers: {
    "content-type": "multipart/form-data",
  },
});

export default {
  postData: (data) =>
    instance({
      method: "POST",
      url: `/${process.env.REACT_APP_API_KEY}`,
      data: data,
    }),

  getAllMessages: (data) =>
    instance({
      method: "POST",
      url: "/getAllMessages",
      data: data,
    }),
};
