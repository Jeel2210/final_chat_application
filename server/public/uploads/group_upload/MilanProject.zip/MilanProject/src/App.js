import Chat from "./pages/chat/chat";
import Home from "./pages/home/home";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "./App.scss";
import React, { useState } from "react";
import io from "socket.io-client";
import "antd/dist/antd.css";
import Sidebar from "./pages/sidebar/Sidebar";

const socket = io.connect("/");

const App = () => {
  const [rederpage, setrenderpage] = useState(false);
  function Appmain(props) {
    return (
      <>
        <div className="app_window">
          <Sidebar />
          <Chat
            username={props.match.params.username}
            roomname={props.match.params.roomname}
            socket={socket}
            rederpage={rederpage}
          />
        </div>
      </>
    );
  }
  console.log(process.env.REACT_APP_API_KEY);

  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact>
            <Home socket={socket} setrenderpage={setrenderpage} />
          </Route>
          <Route path="/chat/:roomname/:username" component={Appmain} />
        </Switch>
      </div>
    </Router>
  );
};

export default App;
