/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, useRef } from "react";
import { InboxOutlined } from "@ant-design/icons";
import { Avatar, Button, Upload } from "antd";
import moment from "moment";
import axios from "axios";
import { RiSendPlaneLine } from "react-icons/ri";
import ModalField from "../../component/Modal/ModalDemo";
import Icons from "../../component/Icons/Icons";
import APi from "../../core/chatRedux/axios";
import "../chat/chat.scss";

const Chat = ({ username, roomname, socket, rederpage }) => {
  const [text, setText] = useState("");
  const [messages, setMessages] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  // const [type, setType] = useState("");

  const [fileStatus, setFileStatus] = useState([]);
  const [files, setFiles] = useState([]);
  const [fileLoading, setFileLoading] = useState(false);

  useEffect(() => {
    socket.on("message", (message) => {
      console.log(message, "ddf");
      // if (typeof message.text === "object") {
      //   const msg = `files:
      //    ${message.text.join()}`;
      //   const m = messages;
      //   // console.log(type, "dfdf");

      //   m.push({
      //     type: type,
      //     userId: message.userId,
      //     username: message.username,
      //     text: msg,
      //   });
      //   setMessages(m);
      //   setFileLoading(false);
      //   setOpenModal(false);
      //   setFiles([]);
      //   // setType("");
      // } else {
      let temp = messages;
      // setType((dd) => {
      temp.push({
        type: message.type ? message.type : null,
        userId: message.userId,
        username: message.username,
        text: message.text,
        date: moment(message.currentDate).format("HH:mm:ss"),
        filename: message.filename,
      });
      // return dd;
      // });
      setMessages([...temp]);
      setFileLoading(false);
      setOpenModal(false);
      setFiles([]);
    });
  }, [socket]);

  useEffect(() => {
    console.log("socke call");
    if (rederpage === false) {
      socket.emit("joinRoom", { username, roomname });
    }
  }, []);

  const sendData = () => {
    if (text !== "") {
      // setType("text");
      socket.emit("chat", text);
      setText("");
    }
  };
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  // upload

  const addFile = (e) => {
    const onlyFiles = [...files];
    const dd = files.findIndex((eee) => eee.name === e.file.originFileObj.name);
    if (dd === -1) {
      onlyFiles.push(e.file.originFileObj);
    }
    setFiles([...onlyFiles]);
  };

  const removeFile = (index) => {
    const dataList = files;
    dataList.splice(index, 1);
    setFiles([...dataList]);
    const fileStatusSet = fileStatus;
    fileStatusSet.splice(index, 1);
    setFileStatus([...fileStatusSet]);
  };

  // submit file

  const addWarroomFile = () => {
    setFileLoading(true);
    const f = [];
    files.forEach((dd, index) => {
      f[index] = { index: index, image: dd };
    });
    // setType("image");
    const form = new FormData();
    files.forEach((element) => {
      form.append("files", element);
    });
    APi.postData(form)
      .then((res) => {
        socket.emit("imageRes", res.data.imageBuffer);
        setOpenModal(false);
        setFileLoading(false);
        setFiles([]);
      })
      .catch((err) => console.error(err));
  };

  // download logic

  const handleDonl = (file, filename) => {
    const url = window.URL.createObjectURL(new Blob([file]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
  };

  // handle image download

  const handleDownload = (url, filename) => {
    axios
      .get(url, {
        responseType: "blob",
      })
      .then((res) => {
        handleDonl(res.data, filename);
      });
  };
  return (
    <>
      <div className="chat">
        <div className="user-name">
          <h2>
            <Avatar
              style={{ cursor: "pointer" }}
              size={{
                xs: 30,
                sm: 30,
                md: 30,
                lg: 30,
                xl: 30,
              }}
            >
              {username && username.split(" ").length > 1
                ? `${username.charAt(0)}${username.split(" ")[1].charAt(0)}`
                : `${username.charAt(0)}`}
            </Avatar>
            {username} <span style={{ fontSize: "0.7rem" }}>in {roomname}</span>
          </h2>
        </div>
        <div className="chat-message">
          {messages.map((i, index) => (
            <>
              <div
                className={
                  i.username === username ? "message mess-right" : "message"
                }
                key={index}
              >
                {i.type === "image" ? (
                  <>
                    <span>{i.username}</span>
                    <p
                      className={
                        i.username !== username ? "img hoverable" : "img"
                      }
                    >
                      <img src={`${i.text}`} alt="img" />
                    </p>
                    {i.username !== username ? (
                      <Icons
                        type="Download"
                        onClick={() => handleDownload(i.text, i.filename)}
                      />
                    ) : null}
                    <span>{i.date}</span>
                  </>
                ) : (
                  <>
                    <span>{i.username}</span>
                    <p>{i.text}</p>
                    <span>{i.date}</span>
                  </>
                )}
              </div>
            </>
          ))}
          <div ref={messagesEndRef} />
        </div>
        <div className="send">
          <input
            placeholder="enter your message"
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                console.log(e);
                sendData();
              }
            }}
          ></input>
           <div className="btn-box1">
            <Icons
              className="svgIcon"
              type="attachemt"
              onClick={() => setOpenModal(true)}
            />
          </div>
          <div className="btn-box" >
            <RiSendPlaneLine className="btn-icon"  onClick={sendData} />
          </div>
        </div>

        {/* upload file modal */}

        <ModalField
          visible={openModal}
          title="Attchment"
          className="uploadmodal"
          onCancel={() => {
            setOpenModal(false);
            setFiles([]);
            setFileLoading(false);
          }}
          footer={false}
        >
          <Upload
            name="avatar"
            accept="crt"
            showUploadList={false}
            onChange={(e) => {
              addFile(e);
            }}
            className="uploadBox"
          >
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">Click to this area to upload file</p>
          </Upload>
          <div
            style={{
              maxHeight: "100px",
              overflow: "auto",
              marginTop: "15px",
            }}
            className="overflowDiv"
          >
            {files.length !== 0 &&
              files.map((file, index) => (
                <div
                  className="controlLabel"
                  key={index}
                  style={{ marginTop: "15px" }}
                >
                  {file.name}
                  {`(${file.size / 1000} KB)`}
                  <Icons
                    type="close"
                    icontype="globle"
                    id={`iFiles_close${index}`}
                    className="removeFiles"
                    margin="10px"
                    onClick={() => removeFile(index)}
                  />
                </div>
              ))}
          </div>
          <div className="footerContent">
            {files.length > 0 ? (
              <Button
                id="warroom_upload"
                disabled={fileStatus.includes(false) || false}
                loading={fileLoading}
                onClick={addWarroomFile}
              >
                Upload
              </Button>
            ) : null}
          </div>
        </ModalField>
      </div>
    </>
  );
};
export default Chat;
