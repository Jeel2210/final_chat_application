import { Button, Col, Input, Row, Form } from "antd";
import React, { useEffect, useState } from "react";
import { useHistory } from "react-router";
import Comman from "../../component/Comman/Comman";
import InputDemo from "../../component/Input/InputDemo";
import "../home/home.scss";
import { HomeStyle } from "./HomeStyle";
// import { Link } from "react-router-dom";

const Homepage = ({ socket, setrenderpage }) => {
  const [load, setLoad] = useState(false);
  const [animate, setanimate] = useState(false);
  const [username, setusername] = useState("");
  const [roomname, setroomname] = useState("");
  const history = useHistory();

  const onfinish = (value) => {
    setLoad(true);
  };

  const sendData = () => {
    setLoad(true);
    if (username !== "" && roomname !== "") {
      setLoad(false);
      history.push(`/chat/${roomname}/${username}`);
      socket.emit("joinRoom", { username, roomname });
      setrenderpage(true);
    } else {
      setLoad(false);
    }
  };
  const [form] = Form.useForm();

  useEffect(() => {
    setanimate(true);
  }, []);

  return (
    <HomeStyle>
      <Row>
        <Col lg={{ span: 10, offset: 2 }} xs={{ span: 16, offset: 2 }}>
          <Comman />
        </Col>
        <Col lg={{ span: 6, offset: 3 }} xs={{ span: 16, offset: 3 }}>
          <Form
            form={form}
            onFinish={onfinish}
            name="basic"
            initialValues={{ remember: true }}
            className={
              animate ? "animated ant-form-vertical" : " ant-form-vertical"
            }
          >
            <h3>Welcome to Chat</h3>
            <h1>Join To ChatApp</h1>
            <InputDemo
              name="username"
              label="User Name"
              rules={[
                {
                  required: true,
                  message: "'Username is required",
                },
              ]}
              Input={
                <Input
                  autoComplete="off"
                  placeholder="Input your user name"
                  onChange={(e) => setusername(e.target.value)}
                />
              }
            />
            <InputDemo
              name="roomname"
              label="Room Name"
              rules={[
                {
                  required: true,
                  message: "'Roomname' is required",
                },
              ]}
              Input={
                <Input
                  autoComplete="off"
                  placeholder="Input your room name"
                  onChange={(e) => setroomname(e.target.value)}
                />
              }
            />

            {/* <NavLink to="/auth/ForgotPass">Forgot Password?</NavLink> */}
            <br />
            <Form.Item shouldUpdate={true}>
              {() => (
                <Button
                  type="primary"
                  htmlType="submit"
                  loading={load}
                  onClick={sendData}
                >
                  Join Now
                </Button>
              )}
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </HomeStyle>
  );
};

export default Homepage;
