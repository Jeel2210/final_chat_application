import { Avatar, Button, Menu, Tooltip } from "antd";
import React, { useEffect, useState } from "react";
import { useHistory } from "react-router";
import Icons from "../../component/Icons/Icons";
import ModalField from "../../component/Modal/ModalDemo";
import axios from "../../core/chatRedux/axios";
import GroupSidebar from "../sidebarGroup/GroupSidebar";
import { SideBarStyle } from "./SidebarStyle";
import ScrollToBottom from "react-scroll-to-bottom";
import { getData, setData } from "../../core/locaStorage/Local";

const Sidebar = ({
  setSelectedUser,
  socket,
  setSelectedGroup,
  setUserExist,
}) => {
  const history = useHistory();
  const [userListData, setuserListData] = useState([]);
  const [newUserListData, setNewUserListData] = useState([]);
  const [dVisible, setDVisible] = useState(false);
  const [modal, setModal] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [getUser, setgetUser] = useState([]);
  const [searchName, setsearchName] = useState("");
  const [groupExist, setGroupExist] = useState(false);

  let final = [];
  // new chat method

  const createNewChat = (status) => {
    setDVisible(!dVisible);
    // if (status === true) {
    axios
      .getAllUsers({
        Authorization: `Bearer ${getData("user").token}`,
      })
      .then((res) => {
        if (res.data.status === true) {
          const userData = getData("user");
          const list = [...res.data.data];
          console.log(userData, list);
          const index = list.findIndex((e) => e.id === userData.id);
          if (index !== -1) {
            list.splice(index, 1);
          }
          setNewUserListData(list);
        } else {
          setNewUserListData([]);
        }
      })
      .catch(() => {
        setNewUserListData([]);
      });
    // } else {
    //   setNewUserListData([]);
    // }
  };

  const handleNewChat = (data) => {
    setData("selectedUser", data);
    setSelectedUser(data);
    const getalluser = getData("receiver");
    if (!getalluser) {
      final.push(data);
      setData("receiver", final);
      setuserListData(final);
    } else {
      if (getalluser.findIndex((ee) => ee.id === data.id) === -1) {
        getalluser.push(data);
        setData("receiver", final);
        setuserListData(getalluser);
      }
    }
  };
  const oncancelmodel = () => {
    setOpenModal(false);
    setsearchName("");
  };
  // change selectedUser

  const setActiveTab = (d) => {
    setUserExist(true);
    history.push("/chat");
    localStorage.removeItem("groupActive");
    localStorage.removeItem("selectedGroup");
    setuserListData((prev) => {
      const list = [...prev];
      const index = list.findIndex((e) => e.id === d.id);
      if (index !== -1) {
        delete list[index].newM;
        console.log(list);
        return list;
      }
      return list;
    });
    setData("selectedUser", d);
    setSelectedUser(d);
  };

  const handleOpenModel = () => {
    setOpenModal(true);
    axios
      .getAllUsers({
        Authorization: `Bearer ${getData("token")}`,
      })
      .then((res) => {
        if (res.data.status === true) {
          const userData = getData("user");
          const list = [...res.data.data];
          const index = list.findIndex((e) => e.id === userData.id);
          if (index !== -1) {
            list.splice(index, 1);
          }
          setgetUser(list);
        } else {
          setgetUser([]);
        }
      })
      .catch(() => {
        setgetUser([]);
      });
  };

  const onChange = (e) => {
    let value = e.target.value;
    setsearchName(value);
    axios
      .getAllUsers({
        Authorization: `Bearer ${getData("token")}`,
      })
      .then((res) => {
        if (res.data.status === true) {
          const userData = getData("user");
          const list = [...res.data.data];
          const index = list.findIndex((e) => e.id === userData.id);
          if (index !== -1) {
            list.splice(index, 1);
          }
          let regString = new RegExp(value, "gi");
          let filterdata = list.filter((item) => {
            if (item.name.match(regString)) {
              return item;
            }
          });
          // setuserListData(filterdata);
          setgetUser(filterdata);
        } else {
          setgetUser([]);
        }
      })
      .catch(() => {
        setgetUser([]);
      });
  };

  const addToMyChat = (user) => {
    localStorage.removeItem("groupActive");
    setData("selectedUser", user);
    setSelectedUser(user);
    const getalluser = getData("receiver");
    if (!getalluser) {
      final.unshift(user);
      setData("receiver", final);
      setuserListData(final);
    } else {
      if (getalluser.findIndex((ee) => ee.id === user.id) === -1) {
        getalluser.unshift(user);
        setData("receiver", getalluser);
        setuserListData(getalluser);
      }
    }
    setOpenModal(false);
  };

  // sidebar userList socket call

  useEffect(() => {
    let sender = getData("user");
    socket.emit("chatUserHistory", {
      sender: sender.id,
      header: { auth_token: getData("user").token },
    });
  }, [socket]);

  // sidebar userList socket Response

  useEffect(() => {
    socket.on("resList", (message) => {
      console.log(message, "///......");
      const userData = getData("user");
      const list = [...message.users];
      const index = list.findIndex((e) => e.id === userData.id);
      if (index !== -1) {
        list.splice(index, 1);
      }
      const ids = list.map((o) => o.id);
      const filtered = list.filter(
        ({ id }, index) => !ids.includes(id, index + 1)
      );
      setuserListData(filtered);
      setUserExist(true);
      setData("receiver", list);
    });
  }, [socket]);

  useEffect(() => {
    if (groupExist) {
      setUserExist(true);
    } else {
      setUserExist(false);
    }
  }, [groupExist]);

  // new message recieved code

  useEffect(() => {
    socket.on("newMessage", (data) => {
      setuserListData((prev) => {
        console.log(data, "data////////////");
        const list = [...prev];
        const index = list.findIndex((e) => e.id === data.sender.id);
        console.log("list", list);
        console.log("index", index);
        console.log("selectedUser", getData("selectedUser"));

        if (index !== -1) {
          if (getData("selectedUser")) {
            if (list[index].id !== getData("selectedUser").id) {
              list[index].newM = true;
              return list;
            }
          } else {
            list[index].newM = true;
            return list;
          }
        } else {
          const localUserList = getData("localUserList");
          const l2 = [...localUserList];
          const i2 = l2.findIndex((e) => e.id === data.sender.id);
          if (i2 !== -1) {
            console.log("gyu");
            l2[i2].newM = true;
            list.unshift(l2[i2]);
            return list;
          } else {
            console.log("na gyu", data.sender, list);
            data.sender.newM = true;
            list.push(data.sender);
            return list;
          }
        }
        return list;
      });
    });
  }, [socket]);

  // useEffect(() => {
  //   if (userListData.length === 0) {
  //     localStorage.removeItem("selectedUser");
  //   }
  // }, []);

  useEffect(() => {
    window.addEventListener("mousedown", (e) => {
      if (dVisible) {
        if (document.getElementById("open")) {
          if (!document.getElementById("open").contains(e.target)) {
            setDVisible(false);
          }
        }
      }
    });
  }, [dVisible]);

  // useEffect(() => {
  //   console.log(groupExist, "d");
  //   if (groupExist) {
  //     setUserExist(true);
  //   }
  // }, [groupExist]);

  const menu = (
    <Menu
      style={{
        height: newUserListData.length !== 0 ? "35vh" : "100%",
        overflow: newUserListData.length !== 0 ? "auto" : "unset",
      }}
    >
      {newUserListData && newUserListData.length !== 0 ? (
        newUserListData.map((item, key) => (
          <Menu.Item className="create-chat-li" key={key}>
            <div
              className="create-chat-outer-div"
              onClick={() => handleNewChat(item)}
            >
              <h6 className="create-chat-title">{item.name}</h6>
              <p className="create-chat-email">{item.email}</p>
            </div>
          </Menu.Item>
        ))
      ) : newUserListData.length === 0 ? (
        <div className="create-chat-outer-div">
          <b className="create-chat-title">No Data Found</b>
        </div>
      ) : null}
    </Menu>
  );

  return (
    <SideBarStyle className="sidebar">
      <header>
        <Tooltip title="Logout">
          <div
            className="header--btn"
            onClick={() => {
              setModal(true);
              // localStorage.clear();
              // history.push("/");
            }}
          >
            <Icons type="logout" style={{ lineHeight: "4px" }} />
          </div>
        </Tooltip>
      </header>
      <div
        className="search"
        style={{ display: "flex", justifyContent: "space-between" }}
      >
        <span>Chat's</span>
        {/* <Dropdown
          overlay={menu}
          visible={dVisible}
          // onVisibleChange={(w) => createNewChat(w)}
          placement="bottomLeft"
        > */}
        <svg
          version="1.1"
          onClick={handleOpenModel}
          id="open"
          className={dVisible ? "open" : "close"}
          xmlns="http://www.w3.org/2000/svg"
          x="0px"
          y="0px"
          viewBox="0 0 60.364 60.364"
          enableBackground="new 0 0 60.364 60.364"
          height="20px"
          width="20px"
          style={{ cursor: "pointer", verticalAlign: "text-top" }}
        >
          <g>
            <path
              d="M54.454,23.18l-18.609-0.002L35.844,5.91C35.845,2.646,33.198,0,29.934,0c-3.263,0-5.909,2.646-5.909,5.91v17.269
		L5.91,23.178C2.646,23.179,0,25.825,0,29.088c0.002,3.264,2.646,5.909,5.91,5.909h18.115v19.457c0,3.267,2.646,5.91,5.91,5.91
		c3.264,0,5.909-2.646,5.91-5.908V34.997h18.611c3.262,0,5.908-2.645,5.908-5.907C60.367,25.824,57.718,23.178,54.454,23.18z"
            />
          </g>
        </svg>
        {/* </Dropdown> */}
      </div>
      <div className="chatList">
        {userListData.length === 0 ? (
          <div className="nodata">NO USER FOUND</div>
        ) : (
          userListData.map((item, key) => (
            <div
              className="chatListItem"
              key={key}
              onClick={() => setActiveTab(item, key)}
            >
              <Avatar
                style={{ cursor: "pointer", marginLeft: "5px" }}
                size={{
                  xs: 30,
                  sm: 30,
                  md: 30,
                  lg: 30,
                  xl: 30,
                }}
              >
                {!item.name ? null : `${item.name.charAt(0)}`}
                {/* MB */}
              </Avatar>
              <div className="chatListItem--lines">
                <div
                  className="chatListItem--line"
                  // style={{ justifyContent: "space-" }}
                >
                  {/* <div
                    style={{
                      width: "10px",
                      height: "10px",
                      borderRadius: "100%",
                      marginRight: "5px",
                      background: "#10af10",
                    }}
                  /> */}
                  <div className="chatListItem--name"> {item.name} </div>
                  {item.newM ? (
                    <div className="chatlistItem--date">
                      <Icons type="newMessage" />
                    </div>
                  ) : null}
                </div>
                <div className="chatListItem--line">
                  <div className="chatListItem--LastMsg">
                    <p>{item.email}</p>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <ModalField
        visible={modal}
        title="Logout User"
        className="uploadmodal"
        onCancel={() => {
          setModal(false);
        }}
        footer={[
          <Button
            key="submitPost"
            onClick={() => {
              localStorage.clear();
              history.push("/");
            }}
          >
            Logout
          </Button>,
          <Button
            key="cancelpost"
            type="primary"
            onClick={() => setModal(false)}
          >
            Cancel
          </Button>,
        ]}
      >
        <span className="permission">Are you sure want to logout ?</span>
      </ModalField>
      <GroupSidebar
        setSelectedGroup={setSelectedGroup}
        socket={socket}
        setGroupExist={setGroupExist}
      />
      <ModalField
        visible={openModal}
        className="uploadmodal"
        onCancel={oncancelmodel}
        footer={false}
        title="Find A Person"
      >
        <div className="overflowDiv">
          <input
            value={searchName}
            placeholder="Search Person To Chat"
            onChange={(e) => onChange(e)}
            style={{
              width: "100%",
              height: "45px",
              borderRadius: "20px",
              borderColor: "#707070",
              fontSize: "15px",
              paddingLeft: "10px",
            }}
          />
          <div
            className="userList"
            style={{ marginTop: "15px", overflow: "auto", height: "300px" }}
          >
            <ScrollToBottom>
              {getUser.length === 0 && (
                <div
                  className="controlLabel"
                  style={{
                    marginTop: "15px",
                    fontSize: "17px",
                    cursor: "pointer",
                    textAlign: "center",
                  }}
                >
                  NO DATA FOUND
                </div>
              )}
              {getUser.length !== 0 &&
                getUser.map((user, index) => (
                  <div
                    className="controlLabel"
                    key={index}
                    style={{
                      marginTop: "15px",
                      fontSize: "17px",
                      cursor: "pointer",
                    }}
                    onClick={() => addToMyChat(user)}
                  >
                    {user.name}
                  </div>
                ))}
            </ScrollToBottom>
          </div>
        </div>
      </ModalField>
    </SideBarStyle>
  );
};

export default Sidebar;
