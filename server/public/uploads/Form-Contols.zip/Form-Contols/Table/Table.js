import React, { useState } from "react";
import PerfectScrollbar from "react-perfect-scrollbar";
import { TablePagination } from "@material-ui/core";

const Table = ({
  constdata,
  tableheader,
  inputshow,
  paginationshow,
  pagevalue,
  limitvalue,
  pageoptions,
  className,
  trclassName,
  thclassName,
  tdclassName,
  inputclassName,
  inputstyle,
  sortby,
  number,
  flagvalue,
}) => {
  const [data, setdata] = useState(constdata);
  const [filterdata, setfilterdata] = useState([]);
  const [page, setPage] = useState(pagevalue);
  const [limit, setLimit] = useState(limitvalue);
  const [sortflag, setsortflag] = useState(flagvalue);
  const mapdata = filterdata && filterdata.length ? filterdata : data;

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  const handleLimitChange = (event) => {
    setLimit(+event.target.value);
    setPage(0);
  };

  const handleshowfilterdata = (event) => {
    const searchinput = event.target.value;
    if (searchinput.length >= 3) {
      let tempdata = data.filter((value) => {
        return (
          value.name.toLowerCase().includes(searchinput.toLowerCase()) ||
          value.position.toLowerCase().includes(searchinput.toLowerCase()) ||
          value.office.toLowerCase().includes(searchinput.toLowerCase()) ||
          value.age
            .toString()
            .toLowerCase()
            .includes(searchinput.toLowerCase()) ||
          value.date
            .toString()
            .toLowerCase()
            .includes(searchinput.toLowerCase()) ||
          value.salary
            .toString()
            .toLowerCase()
            .includes(searchinput.toLowerCase())
        );
      });
      setfilterdata(tempdata);
    } else {
      setfilterdata(data);
    }
  };

  const sortdata = (sortby) => {
    number.map((item) => {
      if (item === sortby) {
        console.log("sort by number");
        if (sortflag === true) {
          const sorteddata = mapdata.sort((a, b) => a[sortby] - b[sortby]);
          setdata(sorteddata);
          setsortflag(!sortflag);
        } else {
          const sorteddata = mapdata.sort((a, b) => b[sortby] - a[sortby]);
          setdata(sorteddata);
          setsortflag(!sortflag);
        }
      } else {
        console.log("sort by not number");
        if (sortflag === true) {
          const sorteddata = mapdata.sort((a, b) =>
            a[sortby] === b[sortby] ? 0 : a[sortby] < b[sortby] ? -1 : 1
          );
          setdata(sorteddata);
          setsortflag(!sortflag);
          console.log("flag is true", sortflag);
        } else {
          const sorteddata = mapdata.sort((a, b) => {
            return a[sortby] === b[sortby] ? 0 : a[sortby] > b[sortby] ? -1 : 1;
          });
          setdata(sorteddata);
          setsortflag(!sortflag);
          console.log("flag is zero", sortflag);
        }
      }
    });
  };
  const caretup = (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      class="bi bi-caret-up-fill"
      viewBox="0 0 16 16"
    >
      <path d="m7.247 4.86-4.796 5.481c-.566.647-.106 1.659.753 1.659h9.592a1 1 0 0 0 .753-1.659l-4.796-5.48a1 1 0 0 0-1.506 0z" />
    </svg>
  );
  const caretdown = (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      class="bi bi-caret-down-fill"
      viewBox="0 0 16 16"
    >
      <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z" />
    </svg>
  );
  const caretright = (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      class="bi bi-caret-right-fill"
      viewBox="0 0 16 16"
    >
      <path d="m12.14 8.753-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z" />
    </svg>
  );

  const caret = (id) => {
    console.log("id", id);
    let caret = caretright;
    if (sortflag === 0) {
      caret = caretright;
    } else if (sortflag) {
      caret = caretdown;
    } else if (sortflag === false) {
      caret = caretup;
    }
    return caret;
  };
  return (
    <div>
      {inputshow && (
        <input
          className={`form-control ${inputclassName}`}
          type="text"
          onChange={handleshowfilterdata}
          style={inputstyle}
        />
      )}
      <PerfectScrollbar>
        <table className={`table ${className}`}>
          <thead>
            <tr className={`${trclassName}`}>
              {tableheader.map(({ name, path }) => (
                <th
                  className={`${thclassName}`}
                  scope="col"
                  onClick={() => {
                    sortby.map((item) => (item === path ? sortdata(path) : ""));
                  }}
                >
                  {name}
                  {sortby.map((item) => (item === path ? caret(item) : ""))}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mapdata.slice(page * limit, page * limit + limit).map((item) => {
              return (
                <tr className={`${trclassName}`} key={item.name + item.salary}>
                  {tableheader.map(({ path }) => {
                    return (
                      <td className={`${tdclassName}`} scope="col">
                        {item[path]}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </PerfectScrollbar>
      {paginationshow && (
        <TablePagination
          component="div"
          count={data.length}
          onPageChange={handlePageChange}
          onRowsPerPageChange={handleLimitChange}
          page={page}
          rowsPerPage={limit}
          rowsPerPageOptions={pageoptions}
        />
      )}
    </div>
  );
};

export default Table;
