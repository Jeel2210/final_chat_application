//Defult props pass when use Button
// children
// className
// this two field required for use this.....!

const Button = ({
  style,
  className,
  id,
  onClick,
  type,
  disabled,
  children,
}) => {
  return (
    <button
      style={style}
      className={`btn ${className}`}
      id={id}
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export default Button;
