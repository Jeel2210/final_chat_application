//Defult props pass when use Textarea field
// register
// name
// value
// onChange method
// this four field required for use this.....!

//if you use number then add one more field
// type="number"

//import Error file
import Error from "../Error/error";
const Textarea = ({
  register,
  name,
  labelname,
  required,
  placeholder,
  value,
  onChange,
  id,
  type,
  pattern,
  maxLength,
  minLength,
  errortype,
  style,
  className,
  labelclassName,
  spanclassName,
  mainclassName,
}) => {
  //borderstyle
  const borderstyle = errortype !== undefined ? "border-danger" : "";

  //number pattern
  const numberregex = /^[0-9\b]+$/;

  //email pattern
  const emailregex =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  // apply pattern for input
  const checkpattern = (patternname) => {
    if (patternname === "email") {
      return emailregex;
    }
    if (patternname === "number") {
      return numberregex;
    }
  };
  return (
    <div className={`${mainclassName}`}>
      {/* label  */}
      <label className={`${labelclassName}`}>{labelname}</label>
      {/* textarea  */}
      <textarea
        {...register(name, {
          pattern: checkpattern(pattern),
          required: required,
          maxLength: maxLength,
          minLength: minLength,
        })}
        className={`form-control ${borderstyle} ${className}`}
        name={name}
        placeholder={placeholder}
        id={id}
        value={value}
        style={style}
        maxLength={maxLength}
        onChange={(e) => {
          onChange(e);
        }}
        onKeyPress={(event) => {
          if (type === "number" && !/[0-9]/.test(event.key)) {
            event.preventDefault();
          }
        }}
      />
      {/* span  */}
      <div className={`${spanclassName}`}>
        <span style={{ color: "red" }}>
          {errortype !== undefined ? Error(name, errortype) : ""}
        </span>
      </div>
    </div>
  );
};

export default Textarea;
