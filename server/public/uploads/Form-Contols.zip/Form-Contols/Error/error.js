const Error = (string, errortype) => {
  //trim the value
  let name = string.charAt(0).toUpperCase() + string.slice(1);

  //create errormessage
  let errorMessage = "";

  //for required
  if (errortype === "required") {
    errorMessage = `${name} is required`;
  }

  //for maxlength
  if (errortype === "maxLength") {
    errorMessage = `${name} is too long`;
  }

  //for minlength
  if (errortype === "minLength") {
    errorMessage = `${name} is too sort`;
  }

  //for number
  if (name === "number" && errortype === "pattern") {
    errorMessage = `Enter ${name} only.`;
  }

  //for email
  if (name === "Email" && errortype === "pattern") {
    errorMessage = `Enter valid email`;
  }

  if (name === "Txtarea" && errortype === "required") {
    errorMessage = `Comments is required`;
  }
  if (name === "Switch" && errortype === "required") {
    errorMessage = `Turn on switch`;
  }
  return errorMessage;
};

export default Error;
