//Defult props pass when use Input field
// register
// name
// value
// onChange method
// this four field required for use this.....!

//if you use number then add one more field
// type="number"

//import Error file
import Error from "../Error/error";
const Input = ({
  register,
  name,
  value,
  type,
  id,
  placeholder,
  onChange,
  errortype,
  required,
  maxLength,
  minLength,
  pattern,
  style,
  className,
  labelname,
  labelclassName,
  mainclassName,
  spanclassName,
}) => {
  //trim the entered value and borderstyle
  const trimvalue = value === undefined ? "" : value.trim();
  const borderstyle = errortype !== undefined ? "border-danger" : "";

  //number pattern
  const numberregex = /^[0-9\b]+$/;

  //email pattern
  const emailregex =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

  // apply pattern for input
  const checkpattern = (patternname) => {
    if (patternname === "email") {
      return emailregex;
    }
    if (patternname === "number") {
      return numberregex;
    }
  };

  //check type for email and number 
  const checktype = (namefield) => {
    if (namefield === "email") {
      return "text";
    } else if (namefield === "number") {
      return "text";
    } else {
      return namefield;
    }
  };
  return (
    <div className={`${mainclassName}`}>
      {/* label */}
      {labelname !== undefined ? (
        <div>
          <label className={`form-label ${labelclassName}`}>{labelname}</label>
        </div>
      ) : (
        ""
      )}
      {/* input */}
      <input
        {...register(name, {
          pattern: checkpattern(pattern),
          required: required,
          maxLength: maxLength,
          minLength: minLength,
        })}
        className={`form-control ${borderstyle} ${className} `}
        style={style}
        value={trimvalue}
        name={name}
        type={checktype(type)}
        placeholder={placeholder}
        maxLength={maxLength}
        onChange={(e) => {
          onChange(e);
        }}
        onKeyPress={(event) => {
          if (type === "number" && !/[0-9]/.test(event.key)) {
            event.preventDefault();
          }
        }}
      />
      {/* span  */}
      <div className={`${spanclassName}`}>
        <span style={{ color: "red" }}>
          {errortype !== undefined ? Error(name, errortype) : ""}
        </span>
      </div>
    </div>
  );
};
export default Input;
