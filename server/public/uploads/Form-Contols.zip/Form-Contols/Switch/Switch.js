import React from "react";

const Switch = ({
  name,
  label,
  register,
  switchvalue,
  onChange,
  className,
  required
}) => {
  return (
    <div class="form-check form-switch">
      <input
        {...register(name,{required:required})}
        className="form-check-input"
        type="checkbox"
        id="switch"
        checked={switchvalue}
        onChange={onChange}
      />
      <label className={`"form-check-label" ${className}`} for="switch">
        {label}
      </label>
    </div>
  );
};

export default Switch;
