import React from "react";

const Checkbox = ({
  checkbtn,
  oncheck,
  items,
  register,
  required,
  className,
  style,
  errortype,
  labelstyle
}) => {
  const borderstyle = errortype !== undefined ? "border-danger" : "";
  return (
    <div>
      {items.map((item, index) => (
        <div key={item}>
          <input
            {...register("Checkbox", { required: required })}
            type="checkbox"
            checked={checkbtn[index]}
            onChange={(e) => oncheck(index)}
            name={item}
            value={item}
            className={`${borderstyle} ${className}`}
            style={style}
          />
          <label className={`form-check-label ${labelstyle}`}>{item}</label>
        </div>
      ))}
    </div>
  );
};

export default Checkbox;
