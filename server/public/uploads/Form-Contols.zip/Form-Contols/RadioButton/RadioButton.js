//Defult props pass when use Input field
// register
// name
// value
// onChange method
// this four field required for use this.....!

//import Error file
import Error from "../Error/error";
const RadioButton = ({
  register,
  onChange,
  items,
  required,
  mainClassName,
  className,
  labelclassName,
  errortype,
  defaultValue,
  value,
  spanclassName,
  name
}) => {
  //borderstyle
  const borderstyle = errortype !== undefined ? "border-danger" : "";
  return (
    <div className={`form-check ${mainClassName}`} onChange={onChange}>
      {items.map((item) => (
        <div key={item}>
          <input
            {...register(name, { required: required })}
            className={`form-check-input ${borderstyle} ${className}`}
            type="radio"
            value={item}
            name="Gender"
            defaultValue={defaultValue}
            checked={value === item}
          />
          <label className={`form-check-label ${labelclassName}`}>{item}</label>
        </div>
      ))}
      {/* span  */}
      <div className={`${spanclassName}`}>
        <span style={{ color: "red" }}>
          {errortype !== undefined ? Error(name, errortype) : ""}
        </span>
      </div>
    </div>
  );
};

export default RadioButton;
