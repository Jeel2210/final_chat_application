import React from "react";

const Slider = ({
  register,
  className,
  name,
  min,
  max,
  value,
  onChange,
  step,
  minmax,
  currentvalueshow,
  labelstyle,
  style,
}) => {
  return (
    <div>
      {minmax && (
        <div>
          <label for="slider" className={`form-label ${labelstyle}`}>
            {min}
          </label>
          <label
            style={{ float: "right" }}
            for="slider"
            className={`form-label ${labelstyle}`}
          >
            {max}
          </label>
        </div>
      )}
      <input
        id="slider"
        {...register(name)}
        step={step}
        min={min}
        max={max}
        type="range"
        className={`form-range ${className}`}
        value={value}
        style={style}
        onChange={(e) => {
          onChange(e);
        }}
      />
      {currentvalueshow && (
        <label for="slider" className={`form-label ${labelstyle}`}>
          Current value: <b>{value}</b>
        </label>
      )}
    </div>
  );
};

export default Slider;
