//Defult props pass when use Input field
// register
// name
// options like that => options={["Gujarat","Goa"]}
// onChange method
// this four field required for use this.....!




//if you pass the required props then dod't pass the defaultValue props

// required ?  defaultValue


//import Error file
import Error from "../Error/error";
const Select = ({
  register,
  name,
  defaultValue,
  options,
  value,
  title,
  id,
  onChange,
  required,
  disabled,
  errortype,
  style,
  className,
  labelname,
  labelclassName,
  mainclassName,
  spanclassName,
}) => {
  // borderstyle
  const borderstyle = errortype !== undefined ? "border-danger" : "";
  return (
    <div className={`${mainclassName}`}>
      {/* label */}
      {labelname !== undefined ? (
        <div>
          <label className={`form-label ${labelclassName}`}>{labelname}</label>
        </div>
      ) : (
        ""
      )}
      {/* input */}
      <select
        className={`form-select ${borderstyle} ${className}`}
        {...register(name, {
          required: required,
        })}
        value={value}
        onChange={onChange}
        defaultValue={defaultValue}
        disabled={disabled}
        style={style}
        onChange={(e) => {
          onChange(e);
        }}
      >
        {/* first option  */}
        {title === undefined ? (
          ""
        ) : (
          <option selected hidden value="">
            {title}
          </option>
        )}
        {/* map the options  */}
        {options.map((item) => (
          <option value={item}>{item}</option>
        ))}
      </select>
      {/* span  */}
      <div className={`${spanclassName}`}>
        <span style={{ color: "red" }}>
          {errortype !== undefined ? Error(name, errortype) : ""}
        </span>
      </div>
    </div>
  );
};

export default Select;
